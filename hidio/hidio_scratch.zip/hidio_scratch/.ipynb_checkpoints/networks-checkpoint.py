import os
import torch as T
import torch.nn.functional as F
import torch.nn as nn
import torch.optim as optim
from torch.distributions.normal import Normal
import numpy as np


class DiscriminatorNetwork(nn.Module):
    """
    
    """
    
    def __init__(self, dimensions name, fc1_size, fc2_size, checkpoint_dir):
        
        super(DiscriminatorNetwork, self).__init__()
        
        pass
    pass
