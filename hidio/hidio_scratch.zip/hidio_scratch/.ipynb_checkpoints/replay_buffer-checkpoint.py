import numpy as np
import copy


class SchedulerBuffer(object):
    """
    
    """
    
    def __init__(self, memory_size, state_dims, num_actions):
        self.memory_size = memory_size
        self.memory_counter = 0
        self.state_dims = state_dims
        self.num_actions = num_actions
        
        self.state_memory = np.zeros(shape=(self.memory_size, self.state_dims), dtype=)
    
    def store_transitions(self):
        pass
    
    @abstractmethod
    def sample_buffer(self):
        pass
    
    
    